pub struct FileInfo {
    pub language: &'static str,
    pub packer:   Option<&'static str>,
    pub obfuscator: Option<&'static str>,
}

pub fn detect(data: &[u8]) -> FileInfo {
    // Binary magic-checks before lossy conversion
    if data.len() >= 8 && data[..4] == [0xCA, 0xFE, 0xBA, 0xBE] {
        let nfat = u32::from_be_bytes([data[4], data[5], data[6], data[7]]);
        if nfat > 10 { // This is Java .class, not a Mach-O fat binary
            return FileInfo {
                language: "Java",
                packer: None,
                obfuscator: None,
            };
        }
    }

    let text = String::from_utf8_lossy(data);
    let packer     = detect_packer(&text);
    let obfuscator = detect_obfuscator(&text);
    let language   = detect_language(&text);

    FileInfo { language, packer, obfuscator }
}

fn detect_packer(text: &str) -> Option<&'static str> {
    if text.contains("UPX0") || text.contains("UPX1") || text.contains("UPX!") {
        return Some("UPX");
    }
    if text.contains("MPRESS1") || text.contains("MPRESS2") {
        return Some("MPRESS");
    }
    if text.contains(".nsp0") || text.contains(".nsp1") {
        return Some("NSPack");
    }
    if text.contains("PECompact2") {
        return Some("PECompact");
    }
    if text.contains("ASPack") {
        return Some("ASPack");
    }
    if text.contains("FSG!") {
        return Some("FSG");
    }
    if text.contains("PEC2") {
        return Some("PECrypt32");
    }
    if text.contains("Themida") {
        return Some("Themida");
    }
    if text.contains("VMProtect") {
        return Some("VMProtect");
    }
    None
}

fn detect_obfuscator(text: &str) -> Option<&'static str> {
    let has_go_runtime = text.contains("runtime.") && text.contains("goroutine");
    let has_build_id   = text.contains("Go build ID") || text.contains("go:buildid");
    let has_go_symbols = text.contains("main.main") || text.contains("main.init");

    if has_go_runtime && !has_build_id && !has_go_symbols {
        return Some("Garble (Go obfuscator)");
    }

    if text.contains("ConfuserEx") || text.contains("Confuser") {
        return Some("ConfuserEx (.NET)");
    }
    if text.contains("de4dot") {
        return Some("de4dot (.NET)");
    }
    if text.contains(".NET Reactor") {
        return Some(".NET Reactor");
    }
    if text.contains("Eazfuscator") {
        return Some("Eazfuscator (.NET)");
    }
    if text.contains("SmartAssembly") {
        return Some("SmartAssembly (.NET)");
    }
    if text.contains("Dotfuscator") {
        return Some("Dotfuscator (.NET)");
    }
    if text.contains("Enigma Protector") {
        return Some("Enigma Protector");
    }
    if text.contains("Obsidium") {
        return Some("Obsidium");
    }
    if text.contains("PyArmor") {
        return Some("Python (PyArmor protected)");
    }
    None
}

fn detect_language(text: &str) -> &'static str {
    // Go
    if text.contains("Go build ID") || text.contains("go:buildid") {
        return "Go";
    }
    if text.contains("runtime.gopanic") || text.contains("goroutine ") {
        return "Go (obfuscated)";
    }

    // Rust
    if text.contains("rustc") || text.contains("core::panicking") {
        return "Rust";
    }
    if text.contains("rust_begin_unwind") || text.contains("__rust_") {
        return "Rust";
    }

    // .NET / C#
    if text.contains("_CorExeMain") || text.contains("mscoree.dll") {
        return ".NET / C#";
    }
    if text.contains("mscorlib") {
        return ".NET / C#";
    }

    // Swift
    if text.contains("_swift_") || text.contains("SwiftObject") {
        return "Swift";
    }

    // Python
    if text.contains("__nuitka") || text.contains("nuitka") {
        return "Python (Nuitka)";
    }
    if text.contains("python3") || text.contains("Python 3") {
        return "Python";
    }
    if text.contains(".pydata") || text.contains("PyInstaller") {
        return "Python (PyInstaller)";
    }
    if text.contains("Py_InitializeEx") {
        return "Python (embedded)";
    }

    // Electron
    if text.contains("app.asar") || text.contains("electron") {
        return "Electron (Node.js)";
    }

    // Delphi / Pascal
    if text.contains("Borland") || text.contains("Delphi") {
        return "Delphi / Pascal";
    }
    if text.contains("TApplication") {
        return "Delphi";
    }

    // AutoIt
    if text.contains("AutoIt") || text.contains(">AUTOIT") {
        return "AutoIt";
    }

    // VB6
    if text.contains("VB5!") || text.contains("VB6!") || text.contains("MSVBVM60") {
        return "Visual Basic 6";
    }

    // C++ (MSVC)
    if text.contains("MSVCP") || text.contains("VCRUNTIME") {
        return "C++ (MSVC)";
    }
    if text.contains("libstdc++") || text.contains("libgcc") {
        return "C++ (GCC/MinGW)";
    }

    // C++ (Clang)
    if text.contains("clang") {
        return "C / C++ (Clang)";
    }

    "Unknown / C"
}
